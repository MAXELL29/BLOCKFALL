
import { Tetromino, TetrominoType } from './types';

export const GRID_WIDTH = 10;
export const GRID_HEIGHT = 22; // 20 visible rows + 2 hidden spawn rows
export const VISIBLE_GRID_HEIGHT = 20;
export const CELL_SIZE = 30; // in pixels

export const TETROMINOES: Record<TetrominoType, Tetromino> = {
  'I': {
    shape: [[1, 1, 1, 1]],
    color: '#00FFFF',
    className: 'bg-cyan-400 border-cyan-200'
  },
  'O': {
    shape: [[1, 1], [1, 1]],
    color: '#FFD700',
    className: 'bg-yellow-400 border-yellow-200'
  },
  'T': {
    shape: [[0, 1, 0], [1, 1, 1]],
    color: '#800080',
    className: 'bg-purple-500 border-purple-300'
  },
  'S': {
    shape: [[0, 1, 1], [1, 1, 0]],
    color: '#00FF00',
    className: 'bg-green-500 border-green-300'
  },
  'Z': {
    shape: [[1, 1, 0], [0, 1, 1]],
    color: '#FF0000',
    className: 'bg-red-500 border-red-300'
  },
  'J': {
    shape: [[1, 0, 0], [1, 1, 1]],
    color: '#0000FF',
    className: 'bg-blue-600 border-blue-400'
  },
  'L': {
    shape: [[0, 0, 1], [1, 1, 1]],
    color: '#FFA500',
    className: 'bg-orange-500 border-orange-300'
  },
};

export const PIECE_START_POS: Record<TetrominoType, { x: number, y: number }> = {
    I: { x: 3, y: 0 },
    O: { x: 4, y: 0 },
    T: { x: 3, y: 0 },
    S: { x: 3, y: 0 },
    Z: { x: 3, y: 0 },
    J: { x: 3, y: 0 },
    L: { x: 3, y: 0 },
};

// Super Rotation System (SRS) Wall Kick Data
// For J, L, S, Z, T pieces
export const WALL_KICK_DATA: { [key: number]: [number, number][] } = {
  0: [[0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]], // 0 -> 1
  1: [[0, 0], [1, 0], [1, -1], [0, 2], [1, 2]],    // 1 -> 0
  2: [[0, 0], [1, 0], [1, 1], [0, -2], [1, -2]],    // 1 -> 2
  3: [[0, 0], [-1, 0], [-1, -1], [0, 2], [-1, 2]],  // 2 -> 1
  4: [[0, 0], [1, 0], [1, -1], [0, 2], [1, 2]],     // 2 -> 3
  5: [[0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]], // 3 -> 2
  6: [[0, 0], [-1, 0], [-1, 1], [0, -2], [-1, -2]], // 3 -> 0
  7: [[0, 0], [1, 0], [1, -1], [0, 2], [1, 2]],     // 0 -> 3
};

// For I piece
export const I_WALL_KICK_DATA: { [key: number]: [number, number][] } = {
  0: [[0, 0], [-2, 0], [1, 0], [-2, -1], [1, 2]], // 0 -> 1
  1: [[0, 0], [2, 0], [-1, 0], [2, 1], [-1, -2]],  // 1 -> 0
  2: [[0, 0], [-1, 0], [2, 0], [-1, 2], [2, -1]], // 1 -> 2
  3: [[0, 0], [1, 0], [-2, 0], [1, -2], [-2, 1]], // 2 -> 1
  4: [[0, 0], [2, 0], [-1, 0], [2, 1], [-1, -2]],  // 2 -> 3
  5: [[0, 0], [-2, 0], [1, 0], [-2, -1], [1, 2]], // 3 -> 2
  6: [[0, 0], [1, 0], [-2, 0], [1, -2], [-2, 1]],  // 3 -> 0
  7: [[0, 0], [-1, 0], [2, 0], [-1, 2], [2, -1]],  // 0 -> 3
};

export const GRAVITY_LEVELS = [
    48, 43, 38, 33, 28, 23, 18, 13, 8, 6, 
    5, 5, 5, 4, 4, 4, 3, 3, 3, 2, 
    2, 2, 2, 2, 2, 2, 2, 2, 2, 1
].map(frames => 1000 / (60 / frames)); // Convert frames at 60fps to ms per drop

// Scoring
export const SCORE_VALUES = {
  SINGLE: 100,
  DOUBLE: 300,
  TRIPLE: 500,
  TETRIS: 800,
  T_SPIN_MINI: 100,
  T_SPIN: 400,
  T_SPIN_SINGLE: 800,
  T_SPIN_DOUBLE: 1200,
  T_SPIN_TRIPLE: 1600,
  SOFT_DROP: 1,
  HARD_DROP: 2,
};

export const COMBO_BONUS = 50;
export const BACK_TO_BACK_MULTIPLIER = 1.5;

// Input timing
export const DAS = 170; // ms
export const ARR = 50; // ms
export const LOCK_DELAY = 500; // ms
