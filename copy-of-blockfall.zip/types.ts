
export type TetrominoType = 'I' | 'O' | 'T' | 'S' | 'Z' | 'J' | 'L';

export interface Tetromino {
  shape: number[][];
  color: string;
  className: string;
}

export interface Piece {
  type: TetrominoType;
  shape: number[][];
  x: number;
  y: number;
  rotation: number;
}

export type Grid = (TetrominoType | null)[][];

export enum GameState {
  MainMenu,
  Playing,
  Paused,
  GameOver,
}
