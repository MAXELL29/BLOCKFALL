
import React from 'react';
import Game from './components/Game';

const App: React.FC = () => {
  return (
    <div className="bg-gray-900 min-h-screen text-white flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-4xl mx-auto">
        <header className="text-center mb-4">
          <h1 className="text-5xl font-bold text-shadow text-yellow-400">Blockfall</h1>
        </header>
        <main>
          <Game />
        </main>
        <footer className="text-center mt-4 text-xs text-gray-500">
          <p>Controls: Arrows/WASD to move, Up/W/X to rotate, Z for counter-rotate, Space for hard drop, C to hold, P/Esc to pause.</p>
        </footer>
      </div>
    </div>
  );
};

export default App;
