
import React from 'react';
import { TetrominoType } from '../types';
import NextQueue from './NextQueue';
import HoldPiece from './HoldPiece';

interface HudProps {
  score: number;
  level: number;
  lines: number;
  nextQueue: TetrominoType[];
  holdPiece: TetrominoType | null;
  combo: number;
  isBackToBack: boolean;
}

const HudInfoPanel: React.FC<{ label: string; value: string | number }> = ({ label, value }) => (
    <div className="bg-black bg-opacity-50 p-3 rounded-lg text-center">
        <p className="text-xs text-yellow-400 uppercase tracking-wider">{label}</p>
        <p className="text-2xl font-bold text-white">{value}</p>
    </div>
);


const Hud: React.FC<HudProps> = ({ score, level, lines, nextQueue, holdPiece, combo, isBackToBack }) => {
    return (
        <div className="w-48 flex flex-col gap-4">
            <HoldPiece type={holdPiece} />
            <div className="flex flex-col gap-4">
                <HudInfoPanel label="Score" value={score} />
                <HudInfoPanel label="Level" value={level} />
                <HudInfoPanel label="Lines" value={lines} />
                 {combo > 0 && (
                    <div className="bg-orange-500 p-2 rounded-lg text-center text-white font-bold animate-pulse">
                        <p>COMBO x{combo}</p>
                    </div>
                )}
                {isBackToBack && (
                    <div className="bg-purple-600 p-2 rounded-lg text-center text-white font-bold animate-pulse">
                       <p>BACK-2-BACK</p>
                    </div>
                )}
            </div>
            <NextQueue queue={nextQueue} />
        </div>
    );
};

export default Hud;
