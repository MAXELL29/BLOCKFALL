
import React from 'react';

interface PauseScreenProps {
  onResume: () => void;
  onRestart: () => void;
  onMenu: () => void;
}

const Button: React.FC<{onClick: () => void, children: React.ReactNode}> = ({onClick, children}) => (
    <button
        onClick={onClick}
        className="w-full bg-yellow-400 text-gray-900 font-bold py-3 px-6 rounded-lg text-lg hover:bg-yellow-300 transition-colors duration-200 border-b-4 border-yellow-600 active:border-b-0 active:mt-1"
    >
        {children}
    </button>
);

const PauseScreen: React.FC<PauseScreenProps> = ({ onResume, onRestart, onMenu }) => {
  return (
    <div className="absolute inset-0 bg-black bg-opacity-70 flex items-center justify-center z-10">
      <div className="bg-gray-800 p-10 rounded-xl shadow-2xl border-4 border-gray-600 text-center w-96">
        <h2 className="text-4xl text-yellow-400 mb-8 text-shadow">Paused</h2>
        <div className="space-y-4">
          <Button onClick={onResume}>Resume</Button>
          <Button onClick={onRestart}>Restart</Button>
          <Button onClick={onMenu}>Main Menu</Button>
        </div>
      </div>
    </div>
  );
};

export default PauseScreen;
