
import React from 'react';
import { TetrominoType } from '../types';
import { TETROMINOES } from '../constants';

interface HoldPieceProps {
  type: TetrominoType | null;
}

const MiniBlock: React.FC<{type: TetrominoType}> = ({ type }) => (
  <div className={`w-4 h-4 ${TETROMINOES[type].className} border-b-2 border-r-2`} />
);

const PiecePreview: React.FC<{ type: TetrominoType }> = ({ type }) => {
  const { shape } = TETROMINOES[type];
  const isI = type === 'I';
  const isO = type === 'O';

  return (
    <div className={`grid gap-px ${isI ? 'w-16' : 'w-12'} ${isO ? 'grid-rows-2' : ''}`}>
        {shape.map((row, y) => (
            <div key={y} className="flex justify-center">
                {row.map((cell, x) => (
                    cell ? <MiniBlock key={`${y}-${x}`} type={type} /> : <div key={`${y}-${x}`} className="w-4 h-4" />
                ))}
            </div>
        ))}
    </div>
  );
};


const HoldPiece: React.FC<HoldPieceProps> = ({ type }) => {
  return (
    <div className="bg-black bg-opacity-50 p-2 rounded-lg">
      <h3 className="text-center text-xs text-yellow-400 mb-2">HOLD</h3>
      <div className="bg-gray-800 rounded flex items-center justify-center h-20">
        {type && <PiecePreview type={type} />}
      </div>
    </div>
  );
};

export default HoldPiece;
