
import React from 'react';

interface GameOverScreenProps {
  score: number;
  lines: number;
  level: number;
  onRestart: () => void;
  onMenu: () => void;
}

const Button: React.FC<{onClick: () => void, children: React.ReactNode}> = ({onClick, children}) => (
    <button
        onClick={onClick}
        className="w-full bg-yellow-400 text-gray-900 font-bold py-3 px-6 rounded-lg text-lg hover:bg-yellow-300 transition-colors duration-200 border-b-4 border-yellow-600 active:border-b-0 active:mt-1"
    >
        {children}
    </button>
);

const GameOverScreen: React.FC<GameOverScreenProps> = ({ score, lines, level, onRestart, onMenu }) => {
  return (
    <div className="absolute inset-0 bg-black bg-opacity-80 flex items-center justify-center z-10">
      <div className="bg-gray-800 p-10 rounded-xl shadow-2xl border-4 border-red-500 text-center w-96 animate-pulse">
        <h2 className="text-4xl text-red-500 mb-4 text-shadow">Game Over</h2>
        <div className="text-left text-lg my-6 space-y-2">
            <p><span className="text-yellow-400 font-bold">Final Score:</span> {score}</p>
            <p><span className="text-yellow-400 font-bold">Lines Cleared:</span> {lines}</p>
            <p><span className="text-yellow-400 font-bold">Level Reached:</span> {level}</p>
        </div>
        <div className="space-y-4">
          <Button onClick={onRestart}>Play Again</Button>
          <Button onClick={onMenu}>Main Menu</Button>
        </div>
      </div>
    </div>
  );
};

export default GameOverScreen;
