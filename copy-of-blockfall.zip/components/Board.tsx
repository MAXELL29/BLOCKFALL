
import React from 'react';
import { GRID_WIDTH, VISIBLE_GRID_HEIGHT, CELL_SIZE } from '../constants';
import { Grid, Piece } from '../types';
import Cell from './Cell';

interface BoardProps {
  grid: Grid;
  currentPiece: Piece | null;
}

const Board: React.FC<BoardProps> = ({ grid, currentPiece }) => {
    
    // Calculate ghost piece position
    const ghostPiece = React.useMemo(() => {
        if (!currentPiece) return null;
        let ghost = { ...currentPiece, shape: currentPiece.shape.map(r => [...r]) };
        while (true) {
            ghost.y++;
            for (let y = 0; y < ghost.shape.length; y++) {
                for (let x = 0; x < ghost.shape[y].length; x++) {
                    if (ghost.shape[y][x]) {
                        const newX = ghost.x + x;
                        const newY = ghost.y + y;
                        if (newY >= grid.length || (grid[newY] && grid[newY][newX])) {
                             ghost.y--;
                             return ghost;
                        }
                    }
                }
            }
        }
    }, [currentPiece, grid]);

    const displayGrid = grid.map(row => [...row]);

    // Draw ghost piece
    if (ghostPiece) {
        ghostPiece.shape.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value !== 0) {
                    const gridY = ghostPiece.y + y;
                    const gridX = ghostPiece.x + x;
                    if (gridY >= 0 && gridY < displayGrid.length && gridX >= 0 && gridX < displayGrid[0].length) {
                       if(displayGrid[gridY][gridX] === null) displayGrid[gridY][gridX] = 'GHOST' as any;
                    }
                }
            });
        });
    }

    // Draw current piece
    if (currentPiece) {
        currentPiece.shape.forEach((row, y) => {
            row.forEach((value, x) => {
                if (value !== 0) {
                    const gridY = currentPiece.y + y;
                    const gridX = currentPiece.x + x;
                     if (gridY >= 0 && gridY < displayGrid.length && gridX >= 0 && gridX < displayGrid[0].length) {
                        displayGrid[gridY][gridX] = currentPiece.type;
                    }
                }
            });
        });
    }
    
    return (
        <div
            className="grid bg-black bg-opacity-70 border-4 border-gray-600 shadow-lg"
            style={{
                gridTemplateColumns: `repeat(${GRID_WIDTH}, ${CELL_SIZE}px)`,
                width: GRID_WIDTH * CELL_SIZE,
                height: VISIBLE_GRID_HEIGHT * CELL_SIZE,
            }}
        >
            {displayGrid.slice(-VISIBLE_GRID_HEIGHT).map((row, y) =>
                row.map((cellType, x) => (
                    <Cell key={`${y}-${x}`} type={cellType} ghostPieceType={ghostPiece?.type} />
                ))
            )}
        </div>
    );
};

export default Board;
