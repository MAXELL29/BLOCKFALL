
import React from 'react';
import { TetrominoType } from '../types';
import { TETROMINOES } from '../constants';

interface CellProps {
  // FIX: Add 'GHOST' to the type to allow rendering ghost pieces.
  type: TetrominoType | 'GHOST' | null;
  ghostPieceType?: TetrominoType | null;
}

const Cell: React.FC<CellProps> = ({ type, ghostPieceType }) => {
    let className = 'w-full h-full';
    
    if (type && type !== 'GHOST') {
        className += ` ${TETROMINOES[type].className} border-b-4 border-r-4 shadow-inner`;
    } else if (type === 'GHOST' && ghostPieceType) {
        className += ` ${TETROMINOES[ghostPieceType].className} opacity-30`;
    } else {
        className += ' bg-gray-800 bg-opacity-50 border border-gray-700';
    }

    return <div className={className} />;
};

export default React.memo(Cell);
