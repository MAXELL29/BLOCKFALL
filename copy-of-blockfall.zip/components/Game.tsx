
import React, { useState, useCallback, useEffect, useRef } from 'react';
import {
  GRID_WIDTH, GRID_HEIGHT, TETROMINOES, PIECE_START_POS, GRAVITY_LEVELS,
  WALL_KICK_DATA, I_WALL_KICK_DATA, LOCK_DELAY, SCORE_VALUES, COMBO_BONUS,
  BACK_TO_BACK_MULTIPLIER, DAS, ARR,
} from '../constants';
import { TetrominoType, Piece, Grid, GameState } from '../types';
import Board from './Board';
import Hud from './Hud';
import MainMenu from './MainMenu';
import PauseScreen from './PauseScreen';
import GameOverScreen from './GameOverScreen';

const Game: React.FC = () => {
    const createEmptyGrid = (): Grid => Array.from({ length: GRID_HEIGHT }, () => Array(GRID_WIDTH).fill(null));

    const [gameState, setGameState] = useState<GameState>(GameState.MainMenu);
    const [grid, setGrid] = useState<Grid>(createEmptyGrid);
    const [currentPiece, setCurrentPiece] = useState<Piece | null>(null);
    const [nextQueue, setNextQueue] = useState<TetrominoType[]>([]);
    const [holdPiece, setHoldPiece] = useState<TetrominoType | null>(null);
    const [canHold, setCanHold] = useState(true);
    const [score, setScore] = useState(0);
    const [level, setLevel] = useState(0);
    const [lines, setLines] = useState(0);
    const [combo, setCombo] = useState(-1);
    const [isBackToBack, setIsBackToBack] = useState(false);

    // FIX: Initialize useRef with null and update type to allow null.
    const gameLoopRef = useRef<number | null>(null);
    const dropTimeRef = useRef<number>(0);
    const lastUpdateTimeRef = useRef<number>(0);
    const lockDelayTimerRef = useRef<number | null>(null);
    const moveRequestRef = useRef<{ dx: number, time: number }>({ dx: 0, time: 0 });
    const moveIntervalRef = useRef<number | null>(null);

    const generateBag = useCallback(() => {
        const bag: TetrominoType[] = ['I', 'O', 'T', 'S', 'Z', 'J', 'L'];
        for (let i = bag.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [bag[i], bag[j]] = [bag[j], bag[i]];
        }
        return bag;
    }, []);
    
    const fillNextQueue = useCallback((q: TetrominoType[]) => {
        let newQueue = [...q];
        while (newQueue.length < 6) {
            newQueue.push(...generateBag());
        }
        return newQueue;
    }, [generateBag]);

    const spawnNewPiece = useCallback((queue: TetrominoType[]) => {
        const [nextType, ...remainingQueue] = queue;
        const newPiece: Piece = {
            type: nextType,
            shape: TETROMINOES[nextType].shape.map(row => [...row]),
            x: PIECE_START_POS[nextType].x,
            y: PIECE_START_POS[nextType].y,
            rotation: 0,
        };

        if (checkCollision(newPiece, grid)) {
            setGameState(GameState.GameOver);
            return null;
        }

        setCurrentPiece(newPiece);
        setNextQueue(fillNextQueue(remainingQueue));
        setCanHold(true);
        return newPiece;
    }, [grid, fillNextQueue]);

    const startGame = useCallback(() => {
        setGrid(createEmptyGrid());
        setScore(0);
        setLevel(0);
        setLines(0);
        setHoldPiece(null);
        setCanHold(true);
        setCombo(-1);
        setIsBackToBack(false);
        const initialQueue = fillNextQueue([]);
        spawnNewPiece(initialQueue);
        setGameState(GameState.Playing);
    }, [spawnNewPiece, fillNextQueue]);

    const checkCollision = (piece: Piece, grid: Grid): boolean => {
        for (let y = 0; y < piece.shape.length; y++) {
            for (let x = 0; x < piece.shape[y].length; x++) {
                if (piece.shape[y][x] !== 0) {
                    const newX = piece.x + x;
                    const newY = piece.y + y;
                    if (newX < 0 || newX >= GRID_WIDTH || newY >= GRID_HEIGHT || (newY >=0 && grid[newY] && grid[newY][newX])) {
                        return true;
                    }
                }
            }
        }
        return false;
    };
    
    const rotatePiece = (piece: Piece, direction: number): Piece => {
        const newShape = piece.shape[0].map((_, colIndex) => piece.shape.map(row => row[colIndex]));
        if (direction === 1) { // Clockwise
            newShape.forEach(row => row.reverse());
        } else { // Counter-clockwise
            newShape.reverse();
        }

        const newRotation = (piece.rotation + direction + 4) % 4;
        
        const newPiece: Piece = {
            ...piece,
            shape: newShape,
            rotation: newRotation,
        };

        // SRS Wall Kicks
        const kickData = piece.type === 'I' ? I_WALL_KICK_DATA : WALL_KICK_DATA;
        let kickIndex: number;
        if (direction === 1) { // CW
          kickIndex = piece.rotation * 2;
        } else { // CCW
          kickIndex = newRotation * 2 + 1;
        }

        const kicks = kickData[kickIndex];

        for (const [kx, ky] of kicks) {
            const kickedPiece = { ...newPiece, x: piece.x + kx, y: piece.y - ky }; // SRS y-axis is inverted
            if (!checkCollision(kickedPiece, grid)) {
                return kickedPiece;
            }
        }

        return piece; // Rotation failed
    };
    
    const handleHold = useCallback(() => {
        if (!canHold || gameState !== GameState.Playing) return;

        const newHoldPiece = currentPiece!.type;
        if (holdPiece) {
             const [nextType, ...remainingQueue] = [holdPiece, ...nextQueue];
             const newPiece: Piece = {
                 type: nextType,
                 shape: TETROMINOES[nextType].shape.map(row => [...row]),
                 x: PIECE_START_POS[nextType].x,
                 y: PIECE_START_POS[nextType].y,
                 rotation: 0,
             };
             if (checkCollision(newPiece, grid)) {
                setGameState(GameState.GameOver);
                return;
             }
             setCurrentPiece(newPiece);
             setNextQueue(remainingQueue);
        } else {
            spawnNewPiece(nextQueue);
        }
        setHoldPiece(newHoldPiece);
        setCanHold(false);
    }, [canHold, currentPiece, holdPiece, nextQueue, grid, spawnNewPiece, gameState]);

    const hardDrop = useCallback(() => {
        if (!currentPiece || gameState !== GameState.Playing) return;
        let newPiece = { ...currentPiece };
        let cellsDropped = 0;
        while (!checkCollision({ ...newPiece, y: newPiece.y + 1 }, grid)) {
            newPiece.y += 1;
            cellsDropped++;
        }
        setScore(s => s + cellsDropped * SCORE_VALUES.HARD_DROP);
        lockPiece(newPiece);
    }, [currentPiece, grid, gameState]);

    const lockPiece = (piece: Piece) => {
        const newGrid = grid.map(row => [...row]);
        let isTSpin = false;
        let isTSpinMini = false;

        if (piece.type === 'T') {
            const corners = [
                [piece.y, piece.x],
                [piece.y, piece.x + 2],
                [piece.y + 2, piece.x],
                [piece.y + 2, piece.x + 2]
            ];
            let occupiedCorners = 0;
            corners.forEach(([y, x]) => {
                if (y >= GRID_HEIGHT || x < 0 || x >= GRID_WIDTH || (grid[y] && grid[y][x])) {
                    occupiedCorners++;
                }
            });
            if (occupiedCorners >= 3) {
              isTSpin = true;
            }
        }

        for (let y = 0; y < piece.shape.length; y++) {
            for (let x = 0; x < piece.shape[y].length; x++) {
                if (piece.shape[y][x] !== 0) {
                    if (piece.y + y >= 0) {
                        newGrid[piece.y + y][piece.x + x] = piece.type;
                    }
                }
            }
        }
        
        let clearedLines = 0;
        const gridAfterClear: Grid = [];
        for (let y = newGrid.length - 1; y >= 0; y--) {
            if (newGrid[y].every(cell => cell !== null)) {
                clearedLines++;
            } else {
                gridAfterClear.unshift(newGrid[y]);
            }
        }
        while (gridAfterClear.length < GRID_HEIGHT) {
            gridAfterClear.unshift(Array(GRID_WIDTH).fill(null));
        }
        
        setGrid(gridAfterClear);

        if(clearedLines > 0) {
            let lineScore = 0;
            let specialMove = false;
            
            if (isTSpin) {
                switch(clearedLines) {
                    case 1: lineScore = SCORE_VALUES.T_SPIN_SINGLE; specialMove = true; break;
                    case 2: lineScore = SCORE_VALUES.T_SPIN_DOUBLE; specialMove = true; break;
                    case 3: lineScore = SCORE_VALUES.T_SPIN_TRIPLE; specialMove = true; break;
                    default: break;
                }
            } else {
                switch(clearedLines) {
                    case 1: lineScore = SCORE_VALUES.SINGLE; break;
                    case 2: lineScore = SCORE_VALUES.DOUBLE; break;
                    case 3: lineScore = SCORE_VALUES.TRIPLE; break;
                    case 4: lineScore = SCORE_VALUES.TETRIS; specialMove = true; break;
                    default: break;
                }
            }

            let totalScore = lineScore * (level + 1);

            if (isBackToBack && specialMove) {
                totalScore *= BACK_TO_BACK_MULTIPLIER;
            }
            
            if (clearedLines > 0) {
                setCombo(c => c + 1);
                if (combo > 0) {
                    totalScore += COMBO_BONUS * combo * (level + 1);
                }
            }
            
            setScore(s => s + totalScore);
            setIsBackToBack(specialMove);
            
            const newTotalLines = lines + clearedLines;
            setLines(newTotalLines);
            setLevel(Math.floor(newTotalLines / 10));
        } else {
            setCombo(-1);
        }

        spawnNewPiece(nextQueue);
    };

    const dropPiece = useCallback(() => {
        if (!currentPiece) return;
        const newPiece = { ...currentPiece, y: currentPiece.y + 1 };
        if (!checkCollision(newPiece, grid)) {
            setCurrentPiece(newPiece);
            if (lockDelayTimerRef.current) {
                clearTimeout(lockDelayTimerRef.current);
                lockDelayTimerRef.current = null;
            }
        } else {
            if (!lockDelayTimerRef.current) {
                lockDelayTimerRef.current = window.setTimeout(() => {
                    lockPiece(currentPiece);
                    lockDelayTimerRef.current = null;
                }, LOCK_DELAY);
            }
        }
    }, [currentPiece, grid]);

    const movePiece = (dx: number) => {
        if (!currentPiece) return;
        const newPiece = { ...currentPiece, x: currentPiece.x + dx };
        if (!checkCollision(newPiece, grid)) {
            setCurrentPiece(newPiece);
            // Reset lock delay on successful move
            if (lockDelayTimerRef.current) {
                clearTimeout(lockDelayTimerRef.current);
                lockDelayTimerRef.current = null;
            }
        }
    };
    
    const handleRotation = (direction: 1 | -1) => {
      if(!currentPiece) return;
      const rotated = rotatePiece(currentPiece, direction);
      if (rotated !== currentPiece) {
        setCurrentPiece(rotated);
         if (lockDelayTimerRef.current) {
                clearTimeout(lockDelayTimerRef.current);
                lockDelayTimerRef.current = null;
         }
      }
    };

    const handleKeyDown = useCallback((e: KeyboardEvent) => {
        if (gameState !== GameState.Playing) {
            if (e.key === 'Escape' && gameState === GameState.Paused) {
                setGameState(GameState.Playing);
            }
            return;
        }

        switch (e.key) {
            case 'ArrowLeft':
            case 'a':
                moveRequestRef.current = { dx: -1, time: Date.now() };
                movePiece(-1);
                break;
            case 'ArrowRight':
            case 'd':
                moveRequestRef.current = { dx: 1, time: Date.now() };
                movePiece(1);
                break;
            case 'ArrowDown':
            case 's':
                dropTimeRef.current = 0; // Soft drop
                dropPiece();
                setScore(s => s + SCORE_VALUES.SOFT_DROP);
                break;
            case ' ': // Spacebar
                e.preventDefault();
                hardDrop();
                break;
            case 'ArrowUp':
            case 'w':
            case 'x':
                handleRotation(1); // Clockwise
                break;
            case 'z':
                handleRotation(-1); // Counter-clockwise
                break;
            case 'c':
                handleHold();
                break;
            case 'p':
            case 'Escape':
                setGameState(GameState.Paused);
                break;
        }
    }, [gameState, dropPiece, hardDrop, handleHold]);

    const handleKeyUp = useCallback((e: KeyboardEvent) => {
      if ((e.key === 'ArrowLeft' && moveRequestRef.current.dx === -1) ||
          (e.key === 'a' && moveRequestRef.current.dx === -1) ||
          (e.key === 'ArrowRight' && moveRequestRef.current.dx === 1) ||
          (e.key === 'd' && moveRequestRef.current.dx === 1)) {
        moveRequestRef.current.dx = 0;
        if(moveIntervalRef.current) clearInterval(moveIntervalRef.current);
        moveIntervalRef.current = null;
      }
    }, []);

    useEffect(() => {
        const handleMoveRepeat = () => {
            if (moveRequestRef.current.dx !== 0) {
                if (Date.now() - moveRequestRef.current.time > DAS) {
                    if (!moveIntervalRef.current) {
                        moveIntervalRef.current = window.setInterval(() => {
                            movePiece(moveRequestRef.current.dx);
                        }, ARR);
                    }
                }
            }
        };
        const repeatTimer = setInterval(handleMoveRepeat, 10);
        return () => clearInterval(repeatTimer);
    }, [gameState]);


    useEffect(() => {
        window.addEventListener('keydown', handleKeyDown);
        window.addEventListener('keyup', handleKeyUp);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
            window.removeEventListener('keyup', handleKeyUp);
        };
    }, [handleKeyDown, handleKeyUp]);

    const gameLoop = useCallback((timestamp: number) => {
        if (gameState === GameState.Playing) {
            if (lastUpdateTimeRef.current === 0) {
                lastUpdateTimeRef.current = timestamp;
            }
            const deltaTime = timestamp - lastUpdateTimeRef.current;
            dropTimeRef.current += deltaTime;
            const gravity = GRAVITY_LEVELS[Math.min(level, GRAVITY_LEVELS.length - 1)];

            if (dropTimeRef.current > gravity) {
                dropPiece();
                dropTimeRef.current = 0;
            }
            lastUpdateTimeRef.current = timestamp;
        } else {
             lastUpdateTimeRef.current = 0;
             dropTimeRef.current = 0;
        }
        gameLoopRef.current = requestAnimationFrame(gameLoop);
    }, [gameState, level, dropPiece]);

    useEffect(() => {
        gameLoopRef.current = requestAnimationFrame(gameLoop);
        return () => {
            if (gameLoopRef.current) cancelAnimationFrame(gameLoopRef.current);
        };
    }, [gameLoop]);

    return (
        <div className="flex justify-center gap-4">
            {gameState === GameState.MainMenu && <MainMenu onPlay={startGame} />}
            {gameState === GameState.Paused && <PauseScreen onResume={() => setGameState(GameState.Playing)} onRestart={startGame} onMenu={() => setGameState(GameState.MainMenu)} />}
            {gameState === GameState.GameOver && <GameOverScreen score={score} lines={lines} level={level} onRestart={startGame} onMenu={() => setGameState(GameState.MainMenu)} />}

            {(gameState === GameState.Playing || gameState === GameState.Paused || gameState === GameState.GameOver) && (
                <>
                    <Board grid={grid} currentPiece={currentPiece} />
                    <Hud 
                        score={score} 
                        level={level} 
                        lines={lines}
                        nextQueue={nextQueue}
                        holdPiece={holdPiece}
                        combo={combo}
                        isBackToBack={isBackToBack}
                    />
                </>
            )}
        </div>
    );
};

export default Game;
