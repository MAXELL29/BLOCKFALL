
import React from 'react';
import { TetrominoType } from '../types';
import { TETROMINOES, CELL_SIZE } from '../constants';

interface NextQueueProps {
  queue: TetrominoType[];
}

const MiniBlock: React.FC<{type: TetrominoType}> = ({ type }) => (
  <div className={`w-4 h-4 ${TETROMINOES[type].className} border-b-2 border-r-2`} />
);

const NextPiece: React.FC<{ type: TetrominoType }> = ({ type }) => {
  const { shape } = TETROMINOES[type];
  const isI = type === 'I';
  const isO = type === 'O';

  return (
    <div className="p-2 flex items-center justify-center h-16">
        <div className={`grid gap-px ${isI ? 'w-16' : 'w-12'} ${isO ? 'grid-rows-2' : ''}`}>
            {shape.map((row, y) => (
                <div key={y} className="flex justify-center">
                    {row.map((cell, x) => (
                        cell ? <MiniBlock key={`${y}-${x}`} type={type} /> : <div key={`${y}-${x}`} className="w-4 h-4" />
                    ))}
                </div>
            ))}
        </div>
    </div>
  );
};

const NextQueue: React.FC<NextQueueProps> = ({ queue }) => {
  return (
    <div className="bg-black bg-opacity-50 p-2 rounded-lg">
      <h3 className="text-center text-xs text-yellow-400 mb-2">NEXT</h3>
      <div className="flex flex-col gap-1">
        {queue.slice(0, 5).map((type, index) => (
            <div key={index} className="bg-gray-800 rounded">
                <NextPiece type={type} />
            </div>
        ))}
      </div>
    </div>
  );
};

export default NextQueue;
